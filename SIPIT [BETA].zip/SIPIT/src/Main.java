
import View.login;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author aidil
 */
public class Main {
    public static void main(String[] args) {
        login start = new login();
        start.setVisible(true);
    }
}
